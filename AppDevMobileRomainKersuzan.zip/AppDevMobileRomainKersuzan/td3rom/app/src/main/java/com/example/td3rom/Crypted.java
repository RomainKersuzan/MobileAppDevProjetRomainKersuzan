package com.example.td3rom;


import android.util.Base64;

import java.security.MessageDigest;



public class Crypted {

    static String URL = "aHR0cHM6Ly9teS1qc29uLXNlcnZlci50eXBpY29kZS5jb20vUm9tYWluS2Vyc3V6YW4vcm9tanNvbi8";
    static String messagerror = "";
    //USERNAME : Georgiana
    static String usernameHash = "��4�~���V\u000Fz��0~x�3�X\\jִ)Ǚ�͑�";
    //PASSWORD : hello
    static String passwordHash = ",�M�_��\u000E&�;*Ź�\u001B\u0016\u001E\\\u001F�B^s\u00043b���$";

    public static String getUrl() {
        return new String(Base64.decode(URL,0));
    }


    public static boolean Checkusernameandpassword(String username, String password) {
        try {
            MessageDigest dig = MessageDigest.getInstance("SHA-256");

            String pass = new String(dig.digest(password.getBytes()));
            String user = new String(dig.digest(username.getBytes()));
            System.out.println("pass"+pass);
            System.out.println("user"+user);

            if(passwordHash.equals(pass) && usernameHash.equals(user))
            {
                return true;
            }
            else
            return false;

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }


}
