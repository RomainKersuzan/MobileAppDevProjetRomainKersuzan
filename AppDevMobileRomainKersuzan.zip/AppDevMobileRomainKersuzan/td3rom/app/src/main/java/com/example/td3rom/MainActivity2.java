package com.example.td3rom;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
public class MainActivity2 extends AppCompatActivity {
    private static String usernamee;
    TextView username;
    TextView password;
    Button loginButton;
    @Override
    protected void onStart() {
        super.onStart();

        username = (TextView)findViewById(R.id.UsernameText);
        password = (TextView)findViewById(R.id.PasswordText);
        loginButton = (Button)findViewById(R.id.button);
        loginButton.setOnClickListener(view -> Connexion());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

    }


    protected void Connexion() {
        String passwordd = password.getText().toString();
        usernamee = username.getText().toString();
        if(com.example.td3rom.Crypted.Checkusernameandpassword(usernamee,passwordd)) {
            Intent intent = new Intent(MainActivity2.this, MainActivity.class);
            startActivity(intent);
        }else
        {
            Toast toast=Toast. makeText(getApplicationContext(),"Error ! Wrong username or password",Toast. LENGTH_SHORT);
            toast. setMargin(50,50);
            toast. show();
        }
    }
    public static String getUsername() {
        return usernamee;
    }

}