package com.example.td3rom;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import java.sql.*;

import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private TextView textViewResult;
    private Button buttonRefresh;
    Connection con;
    String uname,pass,ip,port,database;

    String content = "";
    int id =1;
    private View EditText;
    @SuppressLint("NewApi")
    public Connection connection(){
        ip="127.0.0.1";
        database="mobileapp";
        uname="root";
        pass="";
        port="3306";
        StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Connection connection = null;
        String ConnectionURL=null;
        try{
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            ConnectionURL= "jdbc:jtds:sqlserver://"+ ip + ":"+ port+";"+ "databasename="+ database+";user="+uname+";password="+pass+";";
            connection=DriverManager.getConnection(ConnectionURL);

            }
        catch(Exception ex){
            Log.e("Error",ex.getMessage());
        }
        return connection;
        }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        textViewResult = findViewById(R.id.text_view_result);
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Crypted.getUrl())
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        buttonRefresh = (Button)findViewById(R.id.button5);
        buttonRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        JsonPlaceHolderApi jsonPlaceHolderApi = retrofit.create(JsonPlaceHolderApi.class);
        Call<List<Post>> call = jsonPlaceHolderApi.getPosts();
        call.enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {

                List<Post> posts = response.body();
                textViewResult.setText("You are connected");
                content += "\n\n\n\n\n\nWelcome back " +MainActivity2.getUsername()+"\n";
                for (Post post : posts) {
                    content += "\n\n\nID: " + post.getid() + "\n";
                    content += "Account name: " + post.getaccountname() + "\n";
                    content += "amount: " + post.getamount() + "\n";
                    content += "iban: " + post.getiban() + "\n";
                    content += "currency: " + post.getcurrency() + "\n";
                    }
                textViewResult.append(content);

                }


                @Override
                public void onFailure(Call<List<Post>> call, Throwable t) {

                    try{
                        con = connection();
                        if(con!=null)
                        {
                            textViewResult.setText("You are offline");
                            String query="select * from `mobileapp`.`accounts`";
                            Statement st = connection().createStatement();
                            ResultSet rs = st.executeQuery(query);
                            content += "\n\n\n\n\n\nWelcome back " +MainActivity2.getUsername()+"\n";
                            while(rs.next())
                            {
                            textViewResult.setText(( "\n\n\nID: "+rs.getString(1)));
                            textViewResult.setText(("Account name:"+rs.getString(2)));
                            textViewResult.setText(("amount: "+rs.getString(3)));
                            textViewResult.setText(("iban: "+rs.getString(4)));
                            textViewResult.setText(("currency:"+rs.getString(5)));


                            }
                            }
                        } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                }


            });
        }


}
