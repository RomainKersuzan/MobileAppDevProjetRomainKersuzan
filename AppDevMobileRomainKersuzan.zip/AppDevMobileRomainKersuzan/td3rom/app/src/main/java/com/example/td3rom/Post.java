package com.example.td3rom;

import com.google.gson.annotations.SerializedName;
public class Post {
    private int id;
    private String account_name;
    private double amount;
    private String iban;
    private String currency;
    @SerializedName("body")
    private String text;
    public int getid() {
        return id;
    }
    public String getaccountname() {
        return account_name;
    }
    public double getamount() {
        return amount;
    }
    public String getiban() {
        return iban;
    }
    public String getcurrency() {
        return currency;
    }
    public String getText() {
        return text;
    }
}

